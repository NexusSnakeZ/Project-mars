function toggleBookContent(bookId) {
    const content = document.getElementById('content-' + bookId);
    const book = document.getElementById(bookId);
    
    // Toggle book content visibility
    if (content.style.display === 'none' || content.style.display === '') {
        content.style.display = 'block';
        book.classList.add('opened');
    } else {
        content.style.display = 'none';
        book.classList.remove('opened');
    }
}

function openPopup(popupId) {
    document.getElementById(popupId).style.display = 'flex';
}

function closePopup(popupId) {
    document.getElementById(popupId).style.display = 'none';
}